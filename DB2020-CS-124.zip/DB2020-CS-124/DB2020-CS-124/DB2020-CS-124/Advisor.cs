﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB2020_CS_124
{
    public partial class Advisor : Form
    {
        int indexRow;

        

        public Advisor()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        private void Show()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Advisor", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }


        private void insertButton_Click(object sender, EventArgs e)
        {
            try
            {
                string id = textBox2.Text;
                int Designation;
                string Salary = textBox3.Text;


                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into Advisor (Id,Designation,Salary )values (@Id,@Designation,@Salary)", con);
                cmd.Parameters.AddWithValue("@Id", textBox2.Text);

                if (comboBox1.Text == "Professor")
                {
                    Designation = 6;
                }
                if (comboBox1.Text == "Associate Professor")
                {
                    Designation = 7;
                }
                if (comboBox1.Text == "Assistant Professor")
                {
                    Designation = 8;
                }
                if (comboBox1.Text == "Lecturer")
                {
                    Designation = 9;
                }
                else
                 { 
                    Designation = 10;
                  }
               
                cmd.Parameters.AddWithValue("@Designation", Designation);
                cmd.Parameters.AddWithValue("@Salary", Salary);
               
                cmd.ExecuteNonQuery();
               
                MessageBox.Show("Inserted ino Advisor");
                Show();
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            string Salary = textBox3.Text;
            int Designation;
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Delete from advisor Where Id = @Id";
            cmd.Parameters.AddWithValue("@Id", textBox2.Text);
            if (comboBox1.Text == "Professor")
            {
                Designation = 6;
            }
            if (comboBox1.Text == "Associate Professor")
            {
                Designation = 7;
            }
            if (comboBox1.Text == "Assistant Professor")
            {
                Designation = 8;
            }
            if (comboBox1.Text == "Lecturer")
            {
                Designation = 9;
            }
            else
            {
                Designation = 10;
            }

            cmd.Parameters.AddWithValue("@Designation", Designation);
            cmd.Parameters.AddWithValue("@Salary", Salary);
            cmd.ExecuteNonQuery();
            
            MessageBox.Show("Deleted from Advisor");
            Show();
            showButton_Click(sender, e);
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Advisor", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void Advisor_Load(object sender, EventArgs e)
        {
          



        }

        

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[indexRow];

            textBox2.Text = row.Cells[0].Value.ToString();
            comboBox1.Text = row.Cells[1].Value.ToString();
            textBox3.Text = row.Cells[2].Value.ToString();
        }
        private void clearFields()
        {
            comboBox1.Text = "";
            
            textBox2.Text = "";
            textBox3.Text = "";

        }
        private void updateButton_Click(object sender, EventArgs e)
        {
            try
            {
                int Designation;
                SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Update Advisor SET Id=@Id,Designation = @Designation,Salary= @Salary where Designation = @Designation", con);
                cmd.Parameters.AddWithValue("@Id", textBox2.Text);
                if (comboBox1.Text == "Professor")
                {
                    Designation = 6;
                }
                if (comboBox1.Text == "Associate Professor")
                {
                    Designation = 7;
                }
                if (comboBox1.Text == "Assistant Professor")
                {
                    Designation = 8;
                }
                if (comboBox1.Text == "Lecturer")
                {
                    Designation = 9;
                }
                else
                {
                    Designation = 10;
                }

                cmd.Parameters.AddWithValue("@Designation", comboBox1.Text);
                cmd.Parameters.AddWithValue("@Salary", textBox3.Text);
                cmd.ExecuteNonQuery();
                
                clearFields();

                MessageBox.Show("your data is update");
                Show();


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Advisor where Id = '" + textBox2.Text + "'";
            
            cmd.ExecuteNonQuery();
            cmd.Parameters.AddWithValue("@Id", textBox2.Text);
            cmd.Parameters.AddWithValue("@Designation", comboBox1.Text);
            cmd.Parameters.AddWithValue("@Salary", textBox3.Text);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            clearFields();
        }
    }
}
