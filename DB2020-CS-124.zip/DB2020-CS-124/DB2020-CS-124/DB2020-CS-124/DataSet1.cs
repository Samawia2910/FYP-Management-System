﻿namespace DB2020_CS_124
{


    partial class DataSet1
    {
        partial class StudentDataTable
        {
        }
    }
}

namespace DB2020_CS_124.DataSet1TableAdapters
{
    partial class ProjectTableAdapter
    {
    }

    public partial class StudentTableAdapter {
    }
}
