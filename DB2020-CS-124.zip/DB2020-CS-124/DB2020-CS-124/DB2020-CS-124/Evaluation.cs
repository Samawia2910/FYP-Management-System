﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB2020_CS_124
{
    public partial class Evaluation : Form
    {
        int indexRow;
        public Evaluation()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void insertButton_Click(object sender, EventArgs e)
        {

        }

        private void Evaluation_Load(object sender, EventArgs e)
        {

        }

        private void insertButton_Click_1(object sender, EventArgs e)
        {
            try
            {
                string Name = textBox2.Text;
                string TotalMarks = textBox3.Text;
                string TotalWeightage = textBox4.Text;
                

                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into Evaluation values (@Name,@TotalMarks,@TotalWeightage)", con);

                cmd.Parameters.AddWithValue("@Name", Name);
                cmd.Parameters.AddWithValue("@TotalMarks", TotalMarks);
                cmd.Parameters.AddWithValue("@TotalWeightage", TotalWeightage);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted into Evaluation");
                Show();
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Evaluation", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void clearFields()
        {
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";



        }
        private void updateButton_Click(object sender, EventArgs e)
        {
            try
            {
                string Name = textBox2.Text;
                string TotalMarks = textBox3.Text;
                string TotalWeightage = textBox4.Text;
                SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Update Evaluation SET Name =@Name, TotalMarks = @TotalMarks, TotalWeightage= @TotalWeightage", con);

                cmd.Parameters.AddWithValue("@Name", Name);
                cmd.Parameters.AddWithValue("@TotalMarks", TotalMarks);
                cmd.Parameters.AddWithValue("@TotalWeightage", TotalWeightage);
                cmd.ExecuteNonQuery();
               
                clearFields();

                MessageBox.Show("your data is update");
                Show();


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            string Name = textBox2.Text;
            string TotalMarks = textBox3.Text;
            string TotalWeightage = textBox4.Text;
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();

            SqlCommand cmd = new SqlCommand("Delete from Evaluation Where Name =@Name", con);

            cmd.Parameters.AddWithValue("@Name", Name);
            cmd.Parameters.AddWithValue("@TotalMarks", TotalMarks);
            cmd.Parameters.AddWithValue("@TotalWeightage", TotalWeightage);

            cmd.ExecuteNonQuery();
            
            clearFields();
            showButton_Click(sender, e);
            MessageBox.Show("Deleted from Evaluation");
            Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string Name = textBox2.Text;
            string TotalMarks = textBox3.Text;
            string TotalWeightage = textBox4.Text;
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Evaluation where Name = '" + textBox2.Text + "'";
            cmd.ExecuteNonQuery();
            cmd.Parameters.AddWithValue("@Name", Name);
            cmd.Parameters.AddWithValue("@TotalMarks", TotalMarks);
            cmd.Parameters.AddWithValue("@TotalWeightage", TotalWeightage);
            cmd.ExecuteNonQuery();
           
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
          indexRow = e.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[indexRow];
            textBox2.Text = row.Cells[1].Value.ToString();
            textBox3.Text = row.Cells[2].Value.ToString();
            textBox4.Text = row.Cells[3].Value.ToString();
           
        }
    }
}
