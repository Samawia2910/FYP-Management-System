﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB2020_CS_124
{
    public partial class Group : Form
    {
        int indexRow;
        public Group()
        {
            InitializeComponent();
        }
        private void Show()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from [Group]", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }


        private void clearFields()
        {
            
            dateTimePicker2.Text = "";
           

        }

        private void insertButton_Click(object sender, EventArgs e)
        {
            try
            {

                string Created_On;
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into [Group] (Created_On) values(@Created_On)", con);
                cmd.Parameters.AddWithValue ("@Created_On", dateTimePicker2.Value.Date);
                cmd.ExecuteNonQuery();
                
                clearFields();
                MessageBox.Show("Inserted into Group");
                Show();
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from [Group]", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Delete from [Group] Where Created_On=@Created_On";
            cmd.Parameters.AddWithValue("@Created_On", dateTimePicker2.Value.Date);
            cmd.ExecuteNonQuery();
           
            clearFields();
            MessageBox.Show("Deleted from Group");
            Show();
            
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("SELECT * FROM [Group] WHERE Created_On=@Created_On", con);
                cmd.Parameters.AddWithValue("@Created_On", dateTimePicker2.Value.Date);
                cmd.ExecuteNonQuery();

                clearFields();

                MessageBox.Show("your data is update");
                Show();


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[indexRow];
            dateTimePicker2.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells[1].Value);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                string Created_On;
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into [Group] (Created_On) values(@Created_On)", con);
                cmd.Parameters.AddWithValue("@Created_On", dateTimePicker2.Value.Date);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted into Group");
                Show();
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from [Group] where Created_On = '" + dateTimePicker2.Value.Date + "'";
            cmd.ExecuteNonQuery();
            cmd.Parameters.AddWithValue("Created_On", dateTimePicker2.Value.Date);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }

}
 

