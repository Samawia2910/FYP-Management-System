﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB2020_CS_124
{
    public partial class GroupEvaluation : Form
    {
        int indexRow;

        DataTable dt;
        SqlDataAdapter db;
        SqlDataReader dr;
        public GroupEvaluation()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void insertButton_Click(object sender, EventArgs e)
        {
            try
            {
                string GroupId = comboBox2.Text;
                string EvaluatedId = comboBox1.Text;
                string ObtainedMarks = textBox1.Text;
                

                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into GroupEvaluation values (@GroupId,@EvaluatedId,@ObtainedMarks,@EvaluationDate)", con);

                cmd.Parameters.AddWithValue("@GroupId", GroupId);
                cmd.Parameters.AddWithValue("@EvaluatedId", EvaluatedId);
                cmd.Parameters.AddWithValue("@ObtainedMarks", ObtainedMarks);
                cmd.Parameters.AddWithValue("@EvaluationDate", dateTimePicker2.Value.Date);
                


                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted into GroupEvaluation");
                Show();
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void GroupEvaluation_Load(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
                SqlCommand cmd = con.CreateCommand();




                db = new SqlDataAdapter("SELECT * FROM [Group] ", con);
                dt = new DataTable();
                db.Fill(dt);
                foreach (DataRow ROW in dt.Rows)
                {
                    comboBox2.Items.Add(ROW["Id"].ToString());

                }
                db = new SqlDataAdapter("SELECT * FROM Evaluation ", con);
                dt = new DataTable();
                db.Fill(dt);
                foreach (DataRow ROW in dt.Rows)
                {
                    comboBox1.Items.Add(ROW["Id"].ToString());

                }


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            dt = new DataTable();

            dr = null;
            cmd = new SqlCommand("SELECT Id FROM [Group] WHERE Id = '" + comboBox2.Text + "'", con);
            dr = cmd.ExecuteReader();

            dr.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            dt = new DataTable();

            dr = null;
            cmd = new SqlCommand("SELECT Id FROM Evaluation WHERE Id = '" + comboBox1.Text + "'", con);
            dr = cmd.ExecuteReader();

            dr.Close();
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from GroupEvaluation", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void clearFields()
        {
            comboBox2.Text = "";
            comboBox1.Text = "";
            textBox1.Text = "";
            dateTimePicker2.Text = "";



        }
        private void updateButton_Click(object sender, EventArgs e)
        {
            try
            {
                string GroupId = comboBox2.Text;
                string EvaluatedId = comboBox1.Text;
                string ObtainedMarks = textBox1.Text;
                SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Update GroupEvaluation SET GroupId = @GroupId,EvaluationDate= @EvaluationDate, ObtainedMarks = @ObtainedMarks where GroupId = @GroupId", con);


                cmd.Parameters.AddWithValue("@GroupId", GroupId);
                cmd.Parameters.AddWithValue("@EvaluatedId", EvaluatedId);
                cmd.Parameters.AddWithValue("@ObtainedMarks", ObtainedMarks);
                cmd.Parameters.AddWithValue("@EvaluationDate", dateTimePicker2.Value.Date);
                cmd.ExecuteNonQuery();
                Show();
                clearFields();

                MessageBox.Show("your data is update");
                Show();


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            string GroupId = comboBox2.Text;
            string EvaluatedId = comboBox1.Text;
            string ObtainedMarks = textBox1.Text;
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();

            SqlCommand cmd = new SqlCommand("Delete from GroupEvaluation Where GroupId = @GroupId", con);
           

            cmd.Parameters.AddWithValue("@GroupId", GroupId);
            cmd.Parameters.AddWithValue("@EvaluatedId", EvaluatedId);
            cmd.Parameters.AddWithValue("@ObtainedMarks", ObtainedMarks);
            cmd.Parameters.AddWithValue("@EvaluationDate", dateTimePicker2.Value.Date);
            cmd.ExecuteNonQuery();
            
            clearFields();

            MessageBox.Show("Deleted from GroupEvaluation");
            Show();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string GroupId = comboBox2.Text;
            string EvaluatedId = comboBox1.Text;
            string ObtainedMarks = textBox1.Text;
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from GroupEvaluation Where GroupId ='" + comboBox2.Text + "'";
            
            cmd.ExecuteNonQuery();
            cmd.Parameters.AddWithValue("@GroupId", GroupId);
            cmd.Parameters.AddWithValue("@EvaluatedId", EvaluatedId);
            cmd.Parameters.AddWithValue("@ObtainedMarks", ObtainedMarks);
            cmd.Parameters.AddWithValue("@EvaluationDate", dateTimePicker2.Value.Date);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[indexRow];
            
            
            comboBox2.Text  = row.Cells[0].Value.ToString();
            comboBox1.Text = row.Cells[1].Value.ToString();
            //dateTimePicker2.Text = row.Cells[4].Value.ToString();
            textBox1.Text = row.Cells[2].Value.ToString();
            dateTimePicker2.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells[3].Value);
            
        }
    }
}
