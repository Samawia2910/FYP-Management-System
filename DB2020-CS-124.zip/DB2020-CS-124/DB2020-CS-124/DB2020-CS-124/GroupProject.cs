﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB2020_CS_124
{
    public partial class GroupProject : Form
    {
        int indexRow;
        DataTable dt;
        SqlDataAdapter db;
        SqlDataReader dr;
        public GroupProject()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        private void clearFields()
        {
            comboBox1.Text = "";
            comboBox2.Text = "";
            dateTimePicker2.Text = "";


        }
        private void Show()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from GroupProject", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void insertButton_Click(object sender, EventArgs e)
        {
            try
            {
                string ProjectId = comboBox1.Text;
                string GroupId = comboBox2.Text;
                string AssignmentDate;
               

                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into GroupProject values (@ProjectId,@GroupId,@AssignmentDate)", con);

                cmd.Parameters.AddWithValue("@ProjectId", ProjectId);
                cmd.Parameters.AddWithValue("@GroupId", GroupId);
                cmd.Parameters.AddWithValue("@AssignmentDate", dateTimePicker2.Value.Date);
                
                cmd.ExecuteNonQuery();
                Show();
                MessageBox.Show("Inserted into GroupProject");
                Show();
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from GroupProject", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Delete from GroupProject Where ProjectId=@ProjectId";
            cmd.Parameters.AddWithValue("@ProjectId", comboBox1.Text);
            cmd.ExecuteNonQuery();
           
            MessageBox.Show("Deleted from GroupProject");
            Show();
            showButton_Click(sender, e);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            dt = new DataTable();


            dr = null;
            cmd = new SqlCommand("SELECT Id FROM Project WHERE Id = '" + comboBox1.Text + "'", con);
            dr = cmd.ExecuteReader();

            dr.Close();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            dt = new DataTable();

            dr = null;
            cmd = new SqlCommand("SELECT Id FROM [Group] WHERE Id = '" + comboBox2.Text + "'", con);
            dr = cmd.ExecuteReader();

            dr.Close();
        }

        private void GroupProject_Load(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
                SqlCommand cmd = con.CreateCommand();




                db = new SqlDataAdapter("SELECT * FROM Project ", con);
                dt = new DataTable();
                db.Fill(dt);
                foreach (DataRow ROW in dt.Rows)
                {
                    comboBox1.Items.Add(ROW["Id"].ToString());

                }
                db = new SqlDataAdapter("SELECT * FROM [Group] ", con);
                dt = new DataTable();
                db.Fill(dt);
                foreach (DataRow ROW in dt.Rows)
                {
                    comboBox2.Items.Add(ROW["Id"].ToString());

                }



            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[indexRow];
            comboBox1.Text = row.Cells[0].Value.ToString();
            comboBox2.Text = row.Cells[1].Value.ToString();
            dateTimePicker2.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells[2].Value);
           
    }

        private void updateButton_Click(object sender, EventArgs e)
        {

            try
            {

                SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Update GroupProject SET ProjectId = @ProjectId,GroupId= @GroupId,AssignmentDate = @AssignmentDate where ProjectId = @ProjectId", con);
                cmd.Parameters.AddWithValue("@ProjectId", comboBox1.Text);
                cmd.Parameters.AddWithValue("@GroupId", comboBox2.Text);
                cmd.Parameters.AddWithValue("@AssignmentDate", dateTimePicker2.Value.Date);
                cmd.ExecuteNonQuery();
                
                clearFields();

                MessageBox.Show("your data is update");
                Show();


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from GroupProject where ProjectId = '" + comboBox1.Text + "'";
            cmd.ExecuteNonQuery();
            cmd.Parameters.AddWithValue("@ProjectId", comboBox1.Text);
            cmd.Parameters.AddWithValue("@GroupId", comboBox2.Text);
            cmd.Parameters.AddWithValue("@AssignmentDate", dateTimePicker2.Value.Date);

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
