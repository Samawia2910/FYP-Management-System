﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB2020_CS_124
{
    public partial class GroupStudent : Form
    {
        int indexRow;
        DataTable dt;
        SqlDataAdapter db;
        SqlDataReader dr;
        public GroupStudent()
        {
            InitializeComponent();
        }
        private void Show()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Groupstudent", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void clearFields()
        {


            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            dateTimePicker2.Text = "";

        }
        private void insertButton_Click(object sender, EventArgs e)
        {
            try
            {
                string GroupId = comboBox1.Text;
                string StudentId = comboBox2.Text;
                int Status;
                string AssignmentDate;


                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into GroupStudent values (@GroupId,@StudentId,@Status,@AssignmentDate)", con);

                cmd.Parameters.AddWithValue("@GroupId", GroupId);
                cmd.Parameters.AddWithValue("@StudentId", StudentId);

                if (comboBox1.Text == "Active")
                {
                    Status = 3;
                }
                else
                {
                    Status = 4;
                }
                cmd.Parameters.AddWithValue("@Status", Status);
                cmd.Parameters.AddWithValue("@AssignmentDate", dateTimePicker2.Value.Date);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted into GroupStudent");
                Show();
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from GroupStudent", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            dt = new DataTable();

            dr = null;
            cmd = new SqlCommand("SELECT Id FROM [Group] WHERE Id = '" + comboBox1.Text + "'", con);
            dr = cmd.ExecuteReader();

            dr.Close();
        }

        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void GroupStudent_Load(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
                SqlCommand cmd = con.CreateCommand();




                db = new SqlDataAdapter("SELECT * FROM [Group] ", con);
                dt = new DataTable();
                db.Fill(dt);
                foreach (DataRow ROW in dt.Rows)
                {
                    comboBox1.Items.Add(ROW["Id"].ToString());

                }
                db = new SqlDataAdapter("SELECT * FROM  Student", con);
                dt = new DataTable();
                db.Fill(dt);
                foreach (DataRow ROW in dt.Rows)
                {
                    comboBox2.Items.Add(ROW["Id"].ToString());

                }


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }


        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            dt = new DataTable();

            dr = null;
            cmd = new SqlCommand("SELECT Id FROM Student WHERE Id = '" + comboBox1.Text + "'", con);
            dr = cmd.ExecuteReader();

            dr.Close();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Delete from GroupStudent Where GroupId=@GroupId AND StudentId= @StudentId";
            cmd.Parameters.AddWithValue("@GroupId", comboBox1.Text);
            cmd.Parameters.AddWithValue("@StudentId", comboBox2.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Deleted from GroupStudent");
            Show();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            try
            {



                string GroupId = comboBox1.Text;
                string StudentId = comboBox2.Text;
                int Status;
                string AssignmentDate;


                var con = Configuration.getInstance().getConnection();

                SqlCommand cmd = new SqlCommand("Update GroupStudent SET GroupId = @GroupId, StudentId= @StudentId, Status=@Status,AssignmentDate= @Assignmentdate where GroupId = @groupId", con);


                cmd.Parameters.AddWithValue("@GroupId", GroupId);
                cmd.Parameters.AddWithValue("@StudentId", StudentId);

                if (comboBox1.Text == "Active")
                {
                    Status = 3;
                }
                else
                {
                    Status = 4;
                }
                cmd.Parameters.AddWithValue("@Status", Status);
                cmd.Parameters.AddWithValue("@AssignmentDate", dateTimePicker2.Value.Date);
               
                clearFields();

                MessageBox.Show("your data is update");
                Show();


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[indexRow];
            comboBox1.Text = row.Cells[0].Value.ToString();
            comboBox2.Text = row.Cells[1].Value.ToString();
            comboBox3.Text = row.Cells[2].Value.ToString();
            
            dateTimePicker2.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells[3].Value);
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string GroupId = comboBox1.Text;
            string StudentId = comboBox2.Text;
            int Status;
            string AssignmentDate;

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from GroupStudent where GroupId = '" + comboBox1.Text + "'";
            cmd.ExecuteNonQuery();
            cmd.Parameters.AddWithValue("@GroupId", GroupId);
            cmd.Parameters.AddWithValue("@StudentId", StudentId);

            if (comboBox1.Text == "Active")
            {
                Status = 3;
            }
            else
            {
                Status = 4;
            }
            cmd.Parameters.AddWithValue("@Status", Status);
            cmd.Parameters.AddWithValue("@AssignmentDate", dateTimePicker2.Value.Date);

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }
    }
}
 
    


