﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB2020_CS_124
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Person per = new Person();
            per.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Student std = new Student();
            std.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Group grp = new Group();
            grp.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            GroupStudent grpSt = new GroupStudent();
            grpSt.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
           Project Pr = new Project();
            Pr.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            GroupProject grpPr = new GroupProject();
            grpPr.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Advisor ad = new Advisor();
            ad.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ProjectAdvisor grpad = new ProjectAdvisor();
            grpad.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Evaluation ev = new Evaluation();
            ev.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            GroupEvaluation grpev = new GroupEvaluation();
            grpev.Show();
        }
    }
}
