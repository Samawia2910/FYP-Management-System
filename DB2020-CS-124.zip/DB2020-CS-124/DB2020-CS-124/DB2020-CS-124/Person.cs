﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB2020_CS_124
{
    public partial class Person : Form
    {
        int indexRow;
        public Person()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }



        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        private void Show()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Person", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Person", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        
        
        private void clearFields()
        {
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            dateTimePicker2.Text = "";
            comboBox1.Text = "";
            
        }
        private void insertButton_Click(object sender, EventArgs e)
        {


        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void insertButton_Click_1(object sender, EventArgs e)
        {
            try
            {
                string FirstName = textBox2.Text;
                string LastName = textBox3.Text;
                string Contact = textBox4.Text;
                string Email = textBox5.Text;

                int Gender;

                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into Person values (@FirstName,@LastName,@Contact,@Email,@DateOfBirth,@Gender)", con);

                cmd.Parameters.AddWithValue("@FirstName", FirstName);
                cmd.Parameters.AddWithValue("@LastName", LastName);
                cmd.Parameters.AddWithValue("@Contact", Contact);
                cmd.Parameters.AddWithValue("@Email", Email);
                cmd.Parameters.AddWithValue("@DateOfBirth", dateTimePicker2.Value.Date);
                if (comboBox1.Text == "Male")
                {
                    Gender = 1;
                }
                else
                {
                    Gender = 2;
                }
                cmd.Parameters.AddWithValue("@Gender", Gender);
                cmd.ExecuteNonQuery();
                clearFields();
                MessageBox.Show("Inserted into Person");
                Show();
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();

            SqlCommand cmd = new SqlCommand("Delete from Person Where FirstName= @FirstName", con);
            cmd.Parameters.AddWithValue("@FirstName", textBox2.Text);

            cmd.ExecuteNonQuery();
            
            clearFields();
            showButton_Click(sender, e);
            MessageBox.Show("Deleted from Person");
            Show();


        }
        
        private void updateButton_Click(object sender, EventArgs e)
        {
            try
            {
                
                int Gender;
                SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Update Person SET FirstName = @FirstName, LastName= @LastName, Contact=@Contact ,Email= @Email ,DateOfBirth= @DateOfBirth ,Gender= @Gender where FirstName = @FirstName", con);
                
                cmd.Parameters.AddWithValue("@FirstName", textBox2.Text);
                cmd.Parameters.AddWithValue("@LastName", textBox3.Text);
                cmd.Parameters.AddWithValue("@Contact", textBox4.Text);
                cmd.Parameters.AddWithValue("@Email", textBox5.Text);
                cmd.Parameters.AddWithValue("@DateOfBirth", dateTimePicker2.Value.Date);
                if (comboBox1.Text == "Male")
                {
                    Gender = 1;
                }
                else
                {
                    Gender = 2;
                }

                cmd.Parameters.AddWithValue("@Gender", Gender);

                cmd.ExecuteNonQuery();
                
                clearFields();
                
                MessageBox.Show("your data is update");
                Show();


            }
            catch (Exception exp)
            {
            MessageBox.Show(exp.Message);
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            


        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[indexRow];
            textBox2.Text = row.Cells[1].Value.ToString();
            textBox3.Text = row.Cells[2].Value.ToString();
            textBox4.Text = row.Cells[3].Value.ToString();
            textBox5.Text = row.Cells[4].Value.ToString();
            //dateTimePicker2.Text = row.Cells[4].Value.ToString();
            dateTimePicker2.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells[5].Value);
            comboBox1.Text = row.Cells[6].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            clearFields();
        }

        private void Search_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int Gender;
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Person where FirstName = '" + textBox2.Text + "'";
            cmd.Parameters.AddWithValue("@FirstName", textBox2.Text);
            cmd.Parameters.AddWithValue("@LastName", textBox3.Text);
            cmd.Parameters.AddWithValue("@Contact", textBox4.Text);
            cmd.Parameters.AddWithValue("@Email", textBox5.Text);
            cmd.Parameters.AddWithValue("@DateOfBirth", dateTimePicker2.Value.Date);
            if (comboBox1.Text == "Male")
            {
                Gender = 1;
            }
            else
            {
                Gender = 2;
            }

            cmd.Parameters.AddWithValue("@Gender", Gender);
            cmd.ExecuteNonQuery();
            
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
    }

