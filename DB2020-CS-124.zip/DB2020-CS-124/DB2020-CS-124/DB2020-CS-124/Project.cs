﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB2020_CS_124
{
    public partial class Project : Form
    {
        int indexRow;


        public Project()
        {
            InitializeComponent();
        }
        private void Show()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Project", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

            private void insertButton_Click(object sender, EventArgs e)
        {
            try
            {
                
                string Description = textBox2.Text;
                string Title = textBox3.Text;


                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into Project values (@Description,@Title)", con);
                
                cmd.Parameters.AddWithValue("@Description", Description);
                cmd.Parameters.AddWithValue("@Title", Title);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted into Project");
                Show();
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }
        private void clearFields()
        {
           
            textBox2.Text = "";
            textBox3.Text = "";


        }
        private void showButton_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Project", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();

            SqlCommand cmd = new SqlCommand("Delete from Project Where Description= @Description", con);
          
            cmd.Parameters.AddWithValue("@Description", textBox2.Text);
            cmd.Parameters.AddWithValue("@Title", textBox3.Text);
            cmd.ExecuteNonQuery();
           
            clearFields();
            showButton_Click(sender, e);
            MessageBox.Show("Deleted from Project");
            Show();


        }

        private void Project_Load(object sender, EventArgs e)
        {

        }
            private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
            {

            }

            private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
            {
                indexRow = e.RowIndex;
                DataGridViewRow row = dataGridView1.Rows[indexRow];

              
               textBox2.Text = row.Cells[1].Value.ToString();
               textBox3.Text = row.Cells[2].Value.ToString();
            }

        private void updateButton_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Update Project SET Description = @Description, Title= @Title where Description = @Description", con);
                
                cmd.Parameters.AddWithValue("@Description", textBox2.Text);
                cmd.Parameters.AddWithValue("@Title", textBox3.Text);


                cmd.ExecuteNonQuery();
                
                clearFields();

                MessageBox.Show("your data is update");
                Show();


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Project where Description = '" + textBox2.Text + "'";
            cmd.ExecuteNonQuery();
            cmd.Parameters.AddWithValue("@Description", textBox2.Text);
            cmd.Parameters.AddWithValue("@Title", textBox3.Text);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
    }


