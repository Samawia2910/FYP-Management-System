﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB2020_CS_124
{
    public partial class ProjectAdvisor : Form
    {
        int indexRow;
        DataTable dt;
        SqlDataAdapter db;
        SqlDataReader dr;
        public ProjectAdvisor()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            dt = new DataTable();

            dr = null;
            cmd = new SqlCommand("SELECT Id FROM Advisor WHERE Id = '" + comboBox1.Text + "'", con);
            dr = cmd.ExecuteReader();

            dr.Close();

        }
        private void clearFields()
        {
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            dateTimePicker1.Text = "";

        }
        private void insertButton_Click(object sender, EventArgs e)
        {
            try
            {
                string AdvisorId = comboBox1.Text;
                string ProjectId = comboBox2.Text;
                int AdvisorRole;
                string AssignmentDate;


                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into ProjectAdvisor values (@AdvisorId,@ProjectId,@AdvisorRole,@AssignmentDate)", con);

                cmd.Parameters.AddWithValue("@ProjectId", ProjectId);
                cmd.Parameters.AddWithValue("@AdvisorId", AdvisorId);
                if (comboBox3.Text == "Main Advisor")
                {
                    AdvisorRole = 11;
                }
                if (comboBox3.Text == "Co_Advisror")
                {
                    AdvisorRole = 12;
                }
                else
                {
                    AdvisorRole = 14;
                }
                cmd.Parameters.AddWithValue("@AdvisorRole", AdvisorRole);
                cmd.Parameters.AddWithValue("@AssignmentDate", dateTimePicker1.Value.Date);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted into ProjectAdvisor");
                Show();
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[indexRow];
            comboBox1.Text = row.Cells[0].Value.ToString();
            comboBox2.Text = row.Cells[1].Value.ToString();
            comboBox3.Text = row.Cells[2].Value.ToString();

            //dateTimePicker2.Text = row.Cells[4].Value.ToString();
            dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells[3].Value);

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            dt = new DataTable();

            dr = null;
            cmd = new SqlCommand("SELECT Id FROM Project WHERE Id = '" + comboBox2.Text + "'", con);
            dr = cmd.ExecuteReader();

            dr.Close();
        }

        private void ProjectAdvisor_Load(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
                SqlCommand cmd = con.CreateCommand();




                db = new SqlDataAdapter("SELECT * FROM Advisor ", con);
                dt = new DataTable();
                db.Fill(dt);
                foreach (DataRow ROW in dt.Rows)
                {
                    comboBox1.Items.Add(ROW["Id"].ToString());


                }
                db = new SqlDataAdapter("SELECT * FROM Project ", con);
                dt = new DataTable();
                db.Fill(dt);
                foreach (DataRow ROW in dt.Rows)
                {
                    comboBox2.Items.Add(ROW["Id"].ToString());


                }


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from ProjectAdvisor", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            string AdvisorId = comboBox1.Text;
            string ProjectId = comboBox2.Text;
            int AdvisorRole;
            string AssignmentDate;
            try
            {

                SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Update ProjectAdvisor SET AdvisorId= @AdvisorId,ProjectId = @ProjectId, AdvisorRole = @AdvisorRole,AssignmentDate= @AssignmentDate where AdvisorId = @AdvisorId", con);
                cmd.Parameters.AddWithValue("@AdvisorId", AdvisorId);
                cmd.Parameters.AddWithValue("@ProjectId", ProjectId);

                if (comboBox3.Text == "Main Advisor")
                {
                    AdvisorRole = 11;
                }
                if (comboBox3.Text == "Co_Advisror")
                {
                    AdvisorRole = 12;
                }
                else
                {
                    AdvisorRole = 14;

                    cmd.Parameters.AddWithValue("@AdvisorRole", AdvisorRole);
                    cmd.Parameters.AddWithValue("@AssignmentDate", dateTimePicker1.Value.Date);
                    cmd.ExecuteNonQuery();
                    Show();
                    clearFields();

                    MessageBox.Show("your data is update");
                    Show();

                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();

            SqlCommand cmd = new SqlCommand("Delete from ProjectAdvisor Where AdvisorId=@Advisorid", con);
            cmd.Parameters.AddWithValue("@AdvisorId", comboBox1.Text);

            cmd.ExecuteNonQuery();
            
            clearFields();


            MessageBox.Show("Deleted from ProjectAdvisor");
            Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string AdvisorId = comboBox1.Text;
            string ProjectId = comboBox2.Text;
            int AdvisorRole;
            string AssignmentDate;
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from ProjectAdvisor where  AdvisorId = '" + comboBox1.Text + "'";

            cmd.Parameters.AddWithValue("@AdvisorId", AdvisorId);
            cmd.Parameters.AddWithValue("@ProjectId", ProjectId);

            if (comboBox3.Text == "Main Advisor")
            {
                AdvisorRole = 11;
            }
            if (comboBox3.Text == "Co_Advisror")
            {
                AdvisorRole = 12;
            }
            else
            {
                AdvisorRole = 14;

                cmd.Parameters.AddWithValue("@AdvisorRole", AdvisorRole);
                cmd.Parameters.AddWithValue("@AssignmentDate", dateTimePicker1.Value.Date);
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
    }
}
