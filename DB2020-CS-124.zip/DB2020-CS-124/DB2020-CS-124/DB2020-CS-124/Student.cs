﻿using CRUD_Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace DB2020_CS_124
{


    public partial class Student : Form
    {
        int indexRow;

        DataTable dt;
        SqlDataAdapter db;
        SqlDataReader dr;
        private string id = "";
        private string regNo = "";



        public string StrSqlCon { get; private set; }

        public Student()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Student_Load(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
                SqlCommand cmd = con.CreateCommand();




                db = new SqlDataAdapter("SELECT * FROM Person ", con);
                dt = new DataTable();
                db.Fill(dt);
                foreach (DataRow ROW in dt.Rows)
                {
                    comboBox1.Items.Add(ROW["Id"].ToString());

                }


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

        }



        private void insertButton_Click(object sender, EventArgs e)
        {
            try
            {
                string id = comboBox1.Text;
                string regNo = textBox2.Text;
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into Student (Id, RegistrationNo) values(@Id,@RegistrationNo)", con);
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.Parameters.AddWithValue("@RegistrationNo", regNo);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted into Student");

                Show();
                
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {

            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Delete from Student Where Id=@Id";
            cmd.Parameters.AddWithValue("@Id", comboBox1.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Deleted from Student");
            showButton_Click(sender, e);
        }

        private static bool deleteStudent(int id)
        {
            throw new NotImplementedException();
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Student", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void clearFields()
        {
            comboBox1.Text = "";
            textBox2.Text = "";


        }

        private void updateButton_Click(object sender, EventArgs e)

        {
            try
            {

                SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Update Person SET Id = @Id,RegistrationNo= @RegistrationNo where Id = @id", con);
                cmd.Parameters.AddWithValue("@Id", comboBox1.Text);
                cmd.Parameters.AddWithValue("@RegistrationNo", textBox2.Text);
                cmd.ExecuteNonQuery();
                
                clearFields();

                MessageBox.Show("your data is update");
                Show();


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }





           


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            dt = new DataTable();

            dr = null;
            cmd = new SqlCommand("SELECT Id FROM Person WHERE Id = '" + comboBox1.Text + "'", con);
            dr = cmd.ExecuteReader();

            dr.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {


            /*try
            {
                
                if (dreader.Read())
                {
                    comboBox1.Text = dreader[1].ToString();
                    textBox2.Text = dreader[2].ToString();
                    
                }
                else
                {
                    MessageBox.Show(" No Record");
                }
                dreader.Close();
            }
            catch (Exception)
            {
                MessageBox.Show(" No Record");
            }*/
        }





        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[indexRow];
            comboBox1.Text = row.Cells[0].Value.ToString();
            textBox2.Text = row.Cells[1].Value.ToString();


        }

        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Student where Id = '" + comboBox1.Text + "'";
            cmd.ExecuteNonQuery();
            cmd.Parameters.AddWithValue("Id", comboBox1.Text);
            cmd.Parameters.AddWithValue("RegistrationNo", textBox2.Text);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            clearFields();
        }
        private void Show()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Person", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = CRUD_Operations.Configuration.getInstance().getConnection();

            SqlCommand cmd = new SqlCommand("Delete from Student Where Id= @Id", con);
            cmd.Parameters.AddWithValue("@Id", comboBox1.Text);

            cmd.ExecuteNonQuery();
            
            clearFields();
            
            MessageBox.Show("Deleted from Student");
            Show();

        }
    }
}

    

